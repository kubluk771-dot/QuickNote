@echo off
REM Builds QuickNotes.exe from quicknote.py (needs Python from python.org installed)
py -m pip install --upgrade pyinstaller
py -m PyInstaller --onefile --windowed --name QuickNotes quicknote.py
echo.
echo Done! Your app is at: dist\QuickNotes.exe
pause
