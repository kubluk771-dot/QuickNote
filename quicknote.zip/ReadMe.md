***Welcome to QuickNote First things first!***


\*No i haven't tested the Build Bat,

\*No I didn't not make this Claude did,

\*I only Put this on GitHub Bc I felt greedy keeping it to myself

And ye

Enjoy using it!



This is a Open Source app thing ( Hopefully :P )!



