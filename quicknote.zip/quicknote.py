r"""Quick Notes - a small, modern, autosaving notes app for Windows.

* Home page with your recent notes, a Settings page for themes and fonts.
* Notes are plain .txt files in  Documents\QuickNotes  (open them any time).
* Your look-and-feel choices are saved in a tiny settings.json file in
  %APPDATA%\QuickNotes (nothing personal, nothing sent anywhere).
* Ctrl+Alt+N brings the app up from anywhere with a fresh note.
* Ctrl+N new note, Ctrl+F search, Ctrl+D delete (press twice to confirm).

Standard library only: no extra packages, no network access.
"""

import json
import os
import queue
import subprocess
import sys
import threading
import time
import tkinter as tk
import tkinter.font as tkfont
from pathlib import Path

APP_NAME = "Quick Notes"

# ------------------------------------------------------------------ themes
BASE_THEMES = {
    "midnight": {
        "name": "Midnight", "dark": True,
        "bg": "#141518", "side": "#1b1c20", "hover": "#25272d", "search": "#25272d",
        "ghost": "#24262c", "ghost_hover": "#2e3138", "fg": "#ececf1", "muted": "#8a8e9b",
        "accent": "#7c9cff", "danger": "#ff6b7a",
    },
    "light": {
        "name": "Light", "dark": False,
        "bg": "#ffffff", "side": "#f3f4f7", "hover": "#e7e9ef", "search": "#e7e9ef",
        "ghost": "#eceef3", "ghost_hover": "#dcdfe6", "fg": "#1c1d22", "muted": "#7a7f8c",
        "accent": "#4c6fff", "danger": "#d63a4a",
    },
    "paper": {
        "name": "Paper", "dark": False,
        "bg": "#fbf6ec", "side": "#f1e9d8", "hover": "#e8dcc4", "search": "#e8dcc4",
        "ghost": "#eadfca", "ghost_hover": "#dfd1b6", "fg": "#3b3226", "muted": "#8c7f6a",
        "accent": "#b5651d", "danger": "#b3392f",
    },
    "forest": {
        "name": "Forest", "dark": True,
        "bg": "#101714", "side": "#16201b", "hover": "#1f2c26", "search": "#1f2c26",
        "ghost": "#1c2822", "ghost_hover": "#26362e", "fg": "#e4efe8", "muted": "#86a091",
        "accent": "#5fd08a", "danger": "#ff7a7a",
    },
    "berry": {
        "name": "Berry", "dark": True,
        "bg": "#171321", "side": "#1e1930", "hover": "#2a2342", "search": "#2a2342",
        "ghost": "#261f3b", "ghost_hover": "#32294d", "fg": "#efe9fb", "muted": "#9d93b8",
        "accent": "#c792ff", "danger": "#ff7d95",
    },
}
THEME_ORDER = ["midnight", "light", "paper", "forest", "berry"]

ACCENTS = ["#5b8def", "#9b6dff", "#2fbf71", "#ff9f43", "#ff5d8f", "#17b8c9"]

SIZES = {
    "small": ("Small", 11), "medium": ("Medium", 12),
    "large": ("Large", 14), "xlarge": ("Extra large", 16),
}

FONT_CANDIDATES = ["Segoe UI", "Calibri", "Candara", "Arial", "Verdana", "Tahoma",
                   "Trebuchet MS", "Cambria", "Georgia", "Palatino Linotype",
                   "Times New Roman", "Consolas", "Courier New", "Comic Sans MS"]

DEFAULTS = {"theme": "midnight", "accent": "default", "font": "Segoe UI",
            "size": "medium", "start": "home", "on_top": False}

PLACEHOLDER = "Search your notes"
DELETE_LABEL = "Delete note"
DELETE_CONFIRM = "Click again to delete"


# ----------------------------------------------------------------- colours
def _rgb(h: str):
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def mix(a: str, b: str, t: float) -> str:
    ra, rb = _rgb(a), _rgb(b)
    return "#%02x%02x%02x" % tuple(round(x + (y - x) * t) for x, y in zip(ra, rb))


def luminance(h: str) -> float:
    def f(v):
        v /= 255
        return v / 12.92 if v <= 0.03928 else ((v + 0.055) / 1.055) ** 2.4
    r, g, b = _rgb(h)
    return 0.2126 * f(r) + 0.7152 * f(g) + 0.0722 * f(b)


def readable_on(bg: str) -> str:
    dark = "#0e1224"
    lb = luminance(bg)
    c_white = 1.05 / (lb + 0.05)
    c_dark = (lb + 0.05) / (luminance(dark) + 0.05)
    return "#ffffff" if c_white >= c_dark else dark


def resolve_theme(key: str, accent: str = "default") -> dict:
    t = dict(BASE_THEMES.get(key, BASE_THEMES["midnight"]))
    acc = t["accent"] if accent in (None, "default") else accent
    t["accent"] = acc
    t["accent_hover"] = mix(acc, "#ffffff", 0.18) if t["dark"] else mix(acc, "#000000", 0.14)
    t["accent_fg"] = readable_on(acc)
    t["sel"] = mix(t["side"], acc, 0.22 if t["dark"] else 0.18)
    t["seltext"] = mix(t["bg"], acc, 0.35 if t["dark"] else 0.28)
    return t


# ---------------------------------------------------------------- settings
def notes_dir() -> Path:
    override = os.environ.get("QUICKNOTES_DIR")
    if override:
        base = Path(override)
    else:
        home = Path(os.environ.get("USERPROFILE", Path.home()))
        base = home / "Documents" / "QuickNotes"
    base.mkdir(parents=True, exist_ok=True)
    return base


def settings_path() -> Path:
    override = os.environ.get("QUICKNOTES_DIR")
    if override:
        return Path(override) / "settings.json"
    base = Path(os.environ.get("APPDATA", Path.home() / ".quicknotes"))
    return base / "QuickNotes" / "settings.json"


def _is_hex_colour(v) -> bool:
    return (isinstance(v, str) and len(v) == 7 and v.startswith("#")
            and all(ch in "0123456789abcdefABCDEF" for ch in v[1:]))


def load_settings() -> dict:
    s = dict(DEFAULTS)
    try:
        data = json.loads(settings_path().read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return s
    if not isinstance(data, dict):
        return s
    if data.get("theme") in BASE_THEMES:
        s["theme"] = data["theme"]
    if data.get("accent") == "default" or _is_hex_colour(data.get("accent")):
        s["accent"] = data["accent"]
    if isinstance(data.get("font"), str) and data["font"].strip():
        s["font"] = data["font"].strip()[:60]
    if data.get("size") in SIZES:
        s["size"] = data["size"]
    if data.get("start") in ("home", "note"):
        s["start"] = data["start"]
    if isinstance(data.get("on_top"), bool):
        s["on_top"] = data["on_top"]
    return s


def save_settings(s: dict) -> None:
    try:
        p = settings_path()
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps(s, indent=2), encoding="utf-8")
    except OSError:
        pass


def font_choices(root: tk.Tk) -> "list[str]":
    have = {f.lower() for f in tkfont.families(root)}
    out = [n for n in FONT_CANDIDATES if n.lower() in have]
    if len(out) < 2:
        for named in ("TkDefaultFont", "TkFixedFont"):
            fam = tkfont.Font(root, name=named, exists=True).actual("family")
            if fam not in out:
                out.append(fam)
    return out or ["Segoe UI"]


def all_families(root: tk.Tk) -> "list[str]":
    """Every font installed on this PC."""
    return sorted({f for f in tkfont.families(root) if f and not f.startswith("@")},
                  key=str.lower)


# ----------------------------------------------------------------- helpers
def title_of(text: str) -> str:
    for line in text.splitlines():
        line = line.strip()
        if line:
            return line[:200]
    return "Empty note"


def preview_of(text: str) -> str:
    lines = [ln.strip() for ln in text.splitlines() if ln.strip()]
    rest = " ".join(lines[1:])
    return rest[:150] if rest else "No additional text"


def day_kind(mtime: float) -> str:
    t = time.localtime(mtime)
    now = time.localtime()
    if (t.tm_year, t.tm_yday) == (now.tm_year, now.tm_yday):
        return "today"
    y = time.localtime(time.time() - 86400)
    if (t.tm_year, t.tm_yday) == (y.tm_year, y.tm_yday):
        return "yesterday"
    return "older"


def stamp_of(mtime: float) -> str:
    kind = day_kind(mtime)
    t = time.localtime(mtime)
    if kind == "today":
        return time.strftime("%H:%M", t)
    if kind == "yesterday":
        return "Yesterday"
    return time.strftime("%d %b", t)


def edited_text(mtime: float) -> str:
    kind = day_kind(mtime)
    t = time.localtime(mtime)
    if kind == "today":
        return "Edited today at " + time.strftime("%H:%M", t)
    if kind == "yesterday":
        return "Edited yesterday at " + time.strftime("%H:%M", t)
    return "Edited " + time.strftime("%d %b %Y", t)


def ellipsize(text: str, font: tkfont.Font, maxpx: int) -> str:
    if maxpx <= 0:
        return ""
    if font.measure(text) <= maxpx:
        return text
    lo, hi = 0, len(text)
    while lo < hi:
        mid = (lo + hi + 1) // 2
        if font.measure(text[:mid] + "…") <= maxpx:
            lo = mid
        else:
            hi = mid - 1
    return text[:lo].rstrip() + "…"


def round_rect(cv: tk.Canvas, x1, y1, x2, y2, r, **kw):
    r = max(0, min(r, (x2 - x1) / 2, (y2 - y1) / 2))
    pts = [
        x1 + r, y1, x2 - r, y1, x2, y1, x2, y1 + r,
        x2, y2 - r, x2, y2, x2 - r, y2, x1 + r, y2,
        x1, y2, x1, y2 - r, x1, y1 + r, x1, y1,
    ]
    return cv.create_polygon(pts, smooth=True, **kw)


def enable_dpi_awareness() -> None:
    """Stops Windows from blurring the window on high-DPI screens."""
    if sys.platform != "win32":
        return
    import ctypes
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(1)
    except Exception:
        try:
            ctypes.windll.user32.SetProcessDPIAware()
        except Exception:
            pass


def set_titlebar_dark(root: tk.Tk, dark: bool) -> None:
    """Dark title bar on Windows 10/11 (silently does nothing elsewhere)."""
    if sys.platform != "win32":
        return
    try:
        import ctypes
        root.update_idletasks()
        hwnd = ctypes.windll.user32.GetParent(root.winfo_id())
        val = ctypes.c_int(1 if dark else 0)
        for attr in (20, 19):
            if ctypes.windll.dwmapi.DwmSetWindowAttribute(
                hwnd, attr, ctypes.byref(val), ctypes.sizeof(val)
            ) == 0:
                break
    except Exception:
        pass


def hotkey_listener(q: "queue.Queue[str]") -> None:
    """Windows-only global hotkey (Ctrl+Alt+N) using the Win32 API."""
    if sys.platform != "win32":
        q.put("hotkey_fail")
        return
    import ctypes
    from ctypes import wintypes

    user32 = ctypes.windll.user32
    MOD_ALT, MOD_CONTROL, MOD_NOREPEAT = 0x0001, 0x0002, 0x4000
    WM_HOTKEY = 0x0312
    if not user32.RegisterHotKey(None, 1, MOD_CONTROL | MOD_ALT | MOD_NOREPEAT, ord("N")):
        q.put("hotkey_fail")
        return
    q.put("hotkey_ok")
    msg = wintypes.MSG()
    while user32.GetMessageW(ctypes.byref(msg), None, 0, 0) != 0:
        if msg.message == WM_HOTKEY:
            q.put("hotkey")


# ---------------------------------------------------------------- widgets
class Pill(tk.Canvas):
    """A flat, fully rounded button."""

    def __init__(self, parent, app, text, command, kind="ghost", width=None, fit_text=None):
        self.app = app
        self.label = text
        self.command = command
        self.kind = kind          # "accent", "ghost" or "danger"
        self.armed = False        # "click again to confirm" look
        self.hover = False
        self.auto = not width     # width follows the font unless a fixed one is given
        self.fit_text = fit_text or text
        super().__init__(parent, width=width or self._auto_width(), height=app.S(32),
                         bd=0, highlightthickness=0, cursor="hand2")
        self.bind("<Configure>", lambda e: self.draw())
        self.bind("<Enter>", lambda e: self._set_hover(True))
        self.bind("<Leave>", lambda e: self._set_hover(False))
        self.bind("<ButtonRelease-1>", self._click)

    def _set_hover(self, value: bool) -> None:
        self.hover = value
        self.draw()

    def _click(self, e) -> None:
        if 0 <= e.x <= self.winfo_width() and 0 <= e.y <= self.winfo_height():
            self.command()

    def _auto_width(self) -> int:
        font = self.app.f_btn_bold if self.kind == "accent" else self.app.f_btn
        return font.measure(self.fit_text) + self.app.S(30)

    def fit(self) -> None:
        if self.auto:
            self.configure(width=self._auto_width())

    def set_label(self, text: str) -> None:
        self.label = text
        self.draw()

    def draw(self) -> None:
        c = self.app.c
        self.configure(bg=self.master.cget("bg"))
        self.delete("all")
        w, h = self.winfo_width(), self.winfo_height()
        if w < 8:
            return
        if self.kind == "accent":
            fill = c["accent_hover"] if self.hover else c["accent"]
            fg, font = c["accent_fg"], self.app.f_btn_bold
        else:
            fill = c["ghost_hover"] if self.hover else c["ghost"]
            fg = c["danger"] if self.kind == "danger" else c["fg"]
            font = self.app.f_btn
            if self.armed:
                fill, fg = c["danger"], "#ffffff"
        round_rect(self, 1, 1, w - 1, h - 1, h / 2, fill=fill, outline="")
        self.create_text(w / 2, h / 2, text=self.label, fill=fg, font=font)


class Switch(tk.Canvas):
    """A labelled on/off switch, so settings read as settings."""

    def __init__(self, parent, app, text, value, command):
        self.app = app
        self.text = text
        self.on = value
        self.command = command
        S = app.S
        self.tw, self.th = S(34), S(18)
        w = self.tw + S(10) + app.f_body.measure(text) + S(4)
        super().__init__(parent, width=w, height=S(28), bd=0,
                         highlightthickness=0, cursor="hand2")
        self.bind("<Configure>", lambda e: self.draw())
        self.bind("<ButtonRelease-1>", self._click)

    def _click(self, e) -> None:
        if 0 <= e.x <= self.winfo_width() and 0 <= e.y <= self.winfo_height():
            self.toggle()

    def fit(self) -> None:
        S = self.app.S
        self.configure(width=self.tw + S(10) + self.app.f_body.measure(self.text) + S(4))

    def toggle(self) -> None:
        self.on = not self.on
        self.draw()
        self.command(self.on)

    def draw(self) -> None:
        c, S = self.app.c, self.app.S
        self.configure(bg=self.master.cget("bg"))
        self.delete("all")
        w, h = self.winfo_width(), self.winfo_height()
        if w < 8:
            return
        y1 = (h - self.th) / 2
        y2 = y1 + self.th
        round_rect(self, 1, y1, self.tw, y2, self.th / 2,
                   fill=c["accent"] if self.on else c["ghost_hover"], outline="")
        r = self.th / 2 - S(3)
        cx = self.tw - self.th / 2 if self.on else self.th / 2 + 1
        self.create_oval(cx - r, h / 2 - r, cx + r, h / 2 + r,
                         fill="#ffffff" if self.on else c["muted"], outline="")
        self.create_text(self.tw + S(10), h / 2, anchor="w", text=self.text,
                         fill=c["fg"], font=self.app.f_body)


class NoteCard(tk.Canvas):
    """A note: title, then date and a text preview. Sidebar row or Home tile."""

    def __init__(self, parent, app, path, tile=False):
        super().__init__(parent, height=app.S(66), bd=0, highlightthickness=0,
                         cursor="hand2")
        self.app = app
        self.path = path
        self.tile = tile
        self.title = self.preview = self.stamp = ""
        self.hover = False
        self.bind("<Configure>", lambda e: self.draw())
        self.bind("<Enter>", lambda e: self._set_hover(True))
        self.bind("<Leave>", lambda e: self._set_hover(False))
        self.bind("<Button-1>", lambda e: app.select_path(self.path))

    def _set_hover(self, value: bool) -> None:
        self.hover = value
        self.draw()

    def set_data(self, title: str, preview: str, stamp: str) -> None:
        self.title, self.preview, self.stamp = title, preview, stamp
        self.draw()

    def draw(self) -> None:
        app = self.app
        c = app.c
        self.configure(bg=c["bg"] if self.tile else c["side"])
        self.delete("all")
        w, h = self.winfo_width(), self.winfo_height()
        if w < 20:
            return
        selected = (not self.tile) and app.page == "editor" and self.path == app.current
        if selected:
            fill = c["sel"]
        elif self.hover:
            fill = c["hover"]
        else:
            fill = c["side"] if self.tile else None
        if fill:
            round_rect(self, 1, 1, w - 1, h - 1, app.S(12), fill=fill, outline="")
        if selected:
            round_rect(self, app.S(6), h * 0.3, app.S(9), h * 0.7, app.S(2),
                       fill=c["accent"], outline="")
        x = app.S(20)
        maxw = w - x - app.S(14)
        self.create_text(x, h * 0.34, anchor="w", fill=c["fg"], font=app.f_card_title,
                         text=ellipsize(self.title, app.f_card_title, maxw))
        sub = f"{self.stamp}    {self.preview}"
        self.create_text(x, h * 0.68, anchor="w", fill=c["muted"], font=app.f_small,
                         text=ellipsize(sub, app.f_small, maxw))


class Chip(tk.Canvas):
    """A selectable option in a settings row (text, theme preview or colour dot)."""

    def __init__(self, parent, app, group, opt):
        self.app, self.group = app, group
        self.value = opt["value"]
        self.label = opt.get("label", "")
        self.kind = opt.get("kind", "text")
        self.color = opt.get("color")
        self.font = opt.get("font")
        self.swatch = opt.get("swatch")
        self.hover = False
        self.auto = self.kind == "text" and not opt.get("width")
        S = app.S
        if self.kind == "dot":
            w = h = S(34)
        else:
            h = S(36)
            w = opt.get("width") or (app.f_btn.measure(self.label) + S(30))
        super().__init__(parent, width=w, height=h, bd=0, highlightthickness=0,
                         cursor="hand2")
        self.bind("<Configure>", lambda e: self.draw())
        self.bind("<Enter>", lambda e: self._set_hover(True))
        self.bind("<Leave>", lambda e: self._set_hover(False))
        self.bind("<ButtonRelease-1>", self._click)

    def _set_hover(self, value: bool) -> None:
        self.hover = value
        self.draw()

    def fit(self) -> None:
        if self.auto:
            self.configure(width=self.app.f_btn.measure(self.label) + self.app.S(30))

    def _click(self, e) -> None:
        if 0 <= e.x <= self.winfo_width() and 0 <= e.y <= self.winfo_height():
            self.group.pick(self.value)

    def draw(self) -> None:
        app = self.app
        c, S = app.c, app.S
        self.configure(bg=c["bg"])
        self.delete("all")
        w, h = self.winfo_width(), self.winfo_height()
        if w < 8:
            return
        sel = self.group.value == self.value
        if self.kind == "dot":
            if sel:
                self.create_oval(S(2), S(2), w - S(2), h - S(2), outline=c["fg"], width=2)
            inset = S(7) if sel else S(4)
            self.create_oval(inset, inset, w - inset, h - inset, fill=self.color, outline="")
            return
        if self.kind == "swatch":
            t = self.swatch
            round_rect(self, 1, 1, w - 1, h - 1, S(10), fill=t["bg"],
                       outline=c["accent"] if sel else t["ghost_hover"], width=2 if sel else 1)
            self.create_oval(S(12), h / 2 - S(6), S(24), h / 2 + S(6), fill=t["accent"], outline="")
            self.create_text(S(32), h / 2, anchor="w", text=self.label, fill=t["fg"],
                             font=app.f_btn_bold if sel else app.f_btn)
            return
        fill = c["sel"] if sel else (c["ghost_hover"] if self.hover else c["ghost"])
        round_rect(self, 1, 1, w - 1, h - 1, S(10), fill=fill,
                   outline=c["accent"] if sel else "", width=2 if sel else 1)
        self.create_text(w / 2, h / 2, text=self.label,
                         fill=c["accent"] if sel else c["fg"], font=self.font or app.f_btn)


class ChipGroup(tk.Frame):
    """A row/grid of Chips where exactly one is selected."""

    def __init__(self, parent, app, options, value, command, columns=3):
        super().__init__(parent)
        self.app, self.value, self.command = app, value, command
        self.chips = []
        S = app.S
        for i, opt in enumerate(options):
            chip = Chip(self, app, self, opt)
            chip.grid(row=i // columns, column=i % columns, sticky="w",
                      padx=(0, S(8)), pady=(0, S(8)))
            self.chips.append(chip)

    def fit(self) -> None:
        for chip in self.chips:
            chip.fit()

    def pick(self, value) -> None:
        self.value = value
        self.draw()
        self.command(value)

    def set(self, value) -> None:
        self.value = value
        self.draw()

    def draw(self) -> None:
        self.configure(bg=self.app.c["bg"])
        for chip in self.chips:
            chip.draw()


# -------------------------------------------------------------------- app
class QuickNotes:
    def __init__(self, root: tk.Tk) -> None:
        self.root = root
        self.dir = notes_dir()
        self.settings = load_settings()
        self.fonts_available = font_choices(root)
        self.all_fonts = all_families(root)
        installed = {f.lower(): f for f in self.all_fonts}
        self.settings["font"] = installed.get(self.settings["font"].lower()) or self.default_font()
        self.c = resolve_theme(self.settings["theme"], self.settings["accent"])

        self.current: "Path | None" = None
        self.page = "home"
        self.save_job = None
        self.armed_job = None
        self.loading = False
        self.on_top = self.settings["on_top"]
        self.ph_on = True
        self.hotkey_ok = False
        self.paths: "list[Path]" = []
        self.cards: "list[NoteCard]" = []
        self.home_cards: "list[NoteCard]" = []
        self.empty_lbl = None
        self.cache: "dict[Path, tuple[float, str]]" = {}
        self.page_frames: list = []
        self.page_labels: list = []
        self.shortcut_labels: list = []
        self.draw_widgets: list = []
        self.preview_fonts: list = []

        self.scale = max(1.0, root.winfo_fpixels("1i") / 96.0)
        fam = self.settings["font"]
        self.f_title = tkfont.Font(root, family=fam, size=24, weight="bold")
        self.f_head = tkfont.Font(root, family=fam, size=17, weight="bold")
        self.f_section = tkfont.Font(root, family=fam, size=13, weight="bold")
        self.f_body = tkfont.Font(root, family=fam, size=10)
        self.f_small = tkfont.Font(root, family=fam, size=9)
        self.f_btn = tkfont.Font(root, family=fam, size=9)
        self.f_btn_bold = tkfont.Font(root, family=fam, size=10, weight="bold")
        self.f_card_title = tkfont.Font(root, family=fam, size=10, weight="bold")
        self.f_editor = tkfont.Font(root, family=self.settings["font"],
                                    size=SIZES[self.settings["size"]][1])
        # every font in the app follows the Font setting (the editor also follows Text size)
        self.ui_fonts = [self.f_title, self.f_head, self.f_section, self.f_body,
                         self.f_small, self.f_btn, self.f_btn_bold, self.f_card_title]

        root.title(APP_NAME)
        root.geometry(f"{self.S(960)}x{self.S(620)}")
        root.minsize(self.S(720), self.S(520))

        self.query = tk.StringVar()
        self._build_ui()
        self.update_tip()
        self.apply_theme()
        if self.on_top:
            root.attributes("-topmost", True)

        root.protocol("WM_DELETE_WINDOW", self.on_close)
        root.bind("<Control-n>", lambda e: self.new_note())
        root.bind("<Control-f>", lambda e: (self.search_entry.focus_set(), "break")[1])
        root.bind("<Control-d>", lambda e: self.delete_clicked())
        root.bind_all("<MouseWheel>", self.on_wheel)

        self.hotkey_q: "queue.Queue[str]" = queue.Queue()
        threading.Thread(target=hotkey_listener, args=(self.hotkey_q,), daemon=True).start()
        self.root.after(150, self.poll_hotkey)

        self.refresh_list()
        self.open_note(None)
        self.show_page("editor" if self.settings["start"] == "note" else "home")

    def S(self, n: float) -> int:
        return int(round(n * self.scale))

    def default_font(self) -> str:
        return "Segoe UI" if "Segoe UI" in self.fonts_available else self.fonts_available[0]

    # ------------------------------------------------------------------ UI
    def _build_ui(self) -> None:
        S = self.S

        # ---- sidebar
        self.side = tk.Frame(self.root, width=S(290))
        self.side.pack(side="left", fill="y")
        self.side.pack_propagate(False)

        self.head = tk.Frame(self.side)
        self.head.pack(fill="x", padx=S(18), pady=(S(20), S(10)))
        self.title_lbl = tk.Label(self.head, text="Notes", font=self.f_head, anchor="w")
        self.title_lbl.pack(side="left")
        self.count_lbl = tk.Label(self.head, text="", font=self.f_small)
        self.count_lbl.pack(side="right", pady=(S(8), 0))

        self.new_btn = Pill(self.side, self, "+  New note", self.new_note, kind="accent")
        self.new_btn.pack(fill="x", padx=S(18), pady=(0, S(10)))
        self.draw_widgets.append(self.new_btn)

        self.search_box = tk.Canvas(self.side, height=S(38), bd=0, highlightthickness=0)
        self.search_box.pack(fill="x", padx=S(18), pady=(0, S(10)))
        self.search_entry = tk.Entry(self.search_box, textvariable=self.query, bd=0,
                                     relief="flat", highlightthickness=0, font=self.f_body)
        self.search_entry.insert(0, PLACEHOLDER)
        self.search_win = self.search_box.create_window(
            S(16), S(19), window=self.search_entry, anchor="w")
        self.search_box.bind("<Configure>", self.draw_search)
        self.search_entry.bind("<FocusIn>", self.search_focus_in)
        self.search_entry.bind("<FocusOut>", self.search_focus_out)
        self.search_entry.bind("<Escape>", lambda e: (self.query.set(""), self.root.focus_set()))
        self.query.trace_add("write", self.on_query)

        # bottom navigation (packed before the list so it keeps its spot)
        self.nav = tk.Frame(self.side)
        self.nav.pack(side="bottom", fill="x", padx=S(18), pady=(S(6), S(14)))
        self.home_lbl = tk.Label(self.nav, text="Home", font=self.f_body, cursor="hand2")
        self.home_lbl.pack(side="left", padx=(S(4), S(20)))
        self.settings_lbl = tk.Label(self.nav, text="Settings", font=self.f_body,
                                     cursor="hand2")
        self.settings_lbl.pack(side="left")
        self.home_lbl.bind("<Button-1>", lambda e: self.show_page("home"))
        self.settings_lbl.bind("<Button-1>", lambda e: self.show_page("settings"))
        self.nav_line = tk.Frame(self.side, height=1)
        self.nav_line.pack(side="bottom", fill="x", padx=S(18))

        self.list_wrap = tk.Frame(self.side)
        self.list_wrap.pack(fill="both", expand=True, padx=S(10), pady=(0, S(6)))
        self.list_canvas = tk.Canvas(self.list_wrap, bd=0, highlightthickness=0,
                                     yscrollincrement=S(24))
        self.list_canvas.pack(fill="both", expand=True)
        self.list_inner = tk.Frame(self.list_canvas)
        self.list_win = self.list_canvas.create_window(0, 0, window=self.list_inner, anchor="nw")
        self.list_inner.bind(
            "<Configure>",
            lambda e: self.list_canvas.configure(scrollregion=self.list_canvas.bbox("all")))
        self.list_canvas.bind(
            "<Configure>", lambda e: self.list_canvas.itemconfigure(self.list_win, width=e.width))

        # ---- pages
        self.main = tk.Frame(self.root)
        self.main.pack(side="left", fill="both", expand=True)
        self.page_frames.append(self.main)
        self._build_editor()
        self._build_home()
        self._build_settings()

    def _build_editor(self) -> None:
        S = self.S
        self.editor_page = tk.Frame(self.main)
        self.page_frames.append(self.editor_page)

        self.header = tk.Frame(self.editor_page)
        self.header.pack(fill="x", padx=S(32), pady=(S(18), 0))
        self.meta_lbl = tk.Label(self.header, text="New note", font=self.f_small, anchor="w")
        self.meta_lbl.pack(side="left")
        self.del_btn = Pill(self.header, self, DELETE_LABEL, self.delete_clicked,
                            kind="danger", fit_text=DELETE_CONFIRM)
        self.del_btn.pack(side="right")
        self.draw_widgets.append(self.del_btn)

        self.editor_wrap = tk.Frame(self.editor_page)
        self.editor_wrap.pack(fill="both", expand=True, pady=(S(6), 0))
        self.text = tk.Text(
            self.editor_wrap, wrap="word", undo=True, bd=0, relief="flat",
            highlightthickness=0, padx=S(32), pady=S(14), font=self.f_editor,
            spacing1=0, spacing2=S(4), spacing3=S(6), insertwidth=2,
        )
        self.text.pack(fill="both", expand=True)
        self.text.bind("<<Modified>>", self.on_modified)
        self.ph = tk.Label(self.editor_wrap, text="Start typing…", font=self.f_editor,
                           bd=0, padx=0, pady=0)
        self.ph_tip = tk.Label(self.editor_wrap, text="", font=self.f_small, bd=0,
                               padx=0, pady=0, justify="left", anchor="w")
        for w in (self.ph, self.ph_tip):
            w.bind("<Button-1>", lambda e: self.text.focus_set())

        self.footer = tk.Frame(self.editor_page)
        self.footer.pack(fill="x", padx=S(32), pady=(0, S(14)))
        self.top_switch = Switch(self.footer, self, "Always on top", self.on_top,
                                 self.set_on_top)
        self.top_switch.pack(side="left")
        self.draw_widgets.append(self.top_switch)
        self.status_lbl = tk.Label(self.footer, text="", font=self.f_small)
        self.status_lbl.pack(side="right")
        self.page_frames += [self.header, self.editor_wrap, self.footer]

    def _build_home(self) -> None:
        S = self.S
        self.home_page = tk.Frame(self.main)
        inner = tk.Frame(self.home_page)
        inner.pack(fill="both", expand=True, padx=S(48), pady=(S(40), S(18)))
        self.page_frames += [self.home_page, inner]

        def lab(parent, text, font, key, **pack):
            lbl = tk.Label(parent, text=text, font=font, anchor="w", justify="left")
            lbl.pack(anchor="w", **pack)
            self.page_labels.append((lbl, key))
            return lbl

        self.greet_lbl = lab(inner, "", self.f_title, "fg")
        self.home_sub = lab(inner, "", self.f_body, "muted", pady=(S(4), S(18)))

        row = tk.Frame(inner)
        row.pack(anchor="w")
        self.page_frames.append(row)
        self.home_new = Pill(row, self, "+  New note", self.new_note, kind="accent",
                             width=S(150))
        self.home_new.pack(side="left")
        self.home_folder = Pill(row, self, "Open notes folder", self.open_folder)
        self.home_folder.pack(side="left", padx=(S(10), 0))
        self.draw_widgets += [self.home_new, self.home_folder]

        # shortcuts are packed to the bottom first so they never get squeezed out
        self.shortcut_wrap = tk.Frame(inner)
        self.shortcut_wrap.pack(side="bottom", fill="x")
        self.page_frames.append(self.shortcut_wrap)
        lbl = tk.Label(self.shortcut_wrap, text="Shortcuts", font=self.f_card_title, anchor="w")
        lbl.pack(anchor="w", pady=(0, S(6)))
        self.page_labels.append((lbl, "muted"))
        self.shortcut_rows = tk.Frame(self.shortcut_wrap)
        self.shortcut_rows.pack(anchor="w")
        self.page_frames.append(self.shortcut_rows)

        lab(inner, "Recent notes", self.f_card_title, "muted", pady=(S(26), S(6)))
        self.recent_frame = tk.Frame(inner)
        self.recent_frame.pack(fill="x")
        self.page_frames.append(self.recent_frame)

    def _build_settings(self) -> None:
        S = self.S
        self.settings_page = tk.Frame(self.main)
        self.set_canvas = tk.Canvas(self.settings_page, bd=0, highlightthickness=0,
                                    yscrollincrement=S(24))
        self.set_canvas.pack(fill="both", expand=True)
        self.set_inner = tk.Frame(self.set_canvas)
        self.set_win = self.set_canvas.create_window(0, 0, window=self.set_inner, anchor="nw")
        self.set_inner.bind(
            "<Configure>",
            lambda e: self.set_canvas.configure(scrollregion=self.set_canvas.bbox("all")))
        self.set_canvas.bind(
            "<Configure>", lambda e: self.set_canvas.itemconfigure(self.set_win, width=e.width))
        body = tk.Frame(self.set_inner)
        body.pack(fill="x", padx=S(48), pady=(S(36), S(34)))
        self.page_frames += [self.settings_page, self.set_inner, body]

        def lab(text, font, key, pady=(0, 0)):
            lbl = tk.Label(body, text=text, font=font, anchor="w", justify="left")
            lbl.pack(anchor="w", pady=pady)
            self.page_labels.append((lbl, key))
            return lbl

        def group(options, key, columns):
            g = ChipGroup(body, self, options, self.settings[key],
                          lambda v, k=key: self.set_option(k, v), columns=columns)
            g.pack(anchor="w", pady=(0, S(6)))
            self.draw_widgets.append(g)
            self.groups[key] = g
            return g

        self.groups: "dict[str, ChipGroup]" = {}

        lab("Settings", self.f_title, "fg", (0, S(2)))
        lab("Changes are saved automatically.", self.f_body, "muted", (0, S(8)))

        lab("Appearance", self.f_section, "fg", (S(16), S(10)))
        lab("Theme", self.f_body, "fg", (0, S(6)))
        group([{"value": k, "label": BASE_THEMES[k]["name"], "kind": "swatch",
                "swatch": resolve_theme(k), "width": S(150)} for k in THEME_ORDER],
              "theme", 3)

        lab("Accent colour", self.f_body, "fg", (S(8), S(6)))
        group([{"value": "default", "label": "Theme default"}]
              + [{"value": a, "kind": "dot", "color": a} for a in ACCENTS],
              "accent", 8)

        lab("Font", self.f_body, "fg", (S(8), 0))
        font_help = lab("Changes the text everywhere in the app. Pick one below, or type "
                        "the name of any font installed on your PC.",
                        self.f_small, "muted", (0, S(6)))
        font_help.configure(wraplength=S(540))
        font_opts = []
        for fam in self.fonts_available:
            f = tkfont.Font(self.root, family=fam, size=11)
            self.preview_fonts.append(f)
            font_opts.append({"value": fam, "label": fam, "font": f, "width": S(150)})
        group(font_opts, "font", 3)

        crow = tk.Frame(body)
        crow.pack(anchor="w", pady=(0, S(2)))
        self.page_frames.append(crow)
        self.font_entry = tk.Entry(crow, width=26, font=self.f_body, bd=0, relief="flat",
                                   highlightthickness=1)
        self.font_entry.pack(side="left", ipady=S(6), padx=(0, S(8)))
        self.font_entry.bind("<Return>", lambda e: self.use_custom_font())
        self.font_apply = Pill(crow, self, "Use this font", self.use_custom_font)
        self.font_apply.pack(side="left")
        self.draw_widgets.append(self.font_apply)
        self.font_msg = lab("", self.f_small, "muted", (S(2), S(6)))
        self.font_preview = tk.Label(
            body, text="The quick brown fox jumps over the lazy dog.\nAa Bb Cc 0123456789",
            font=self.f_editor, anchor="w", justify="left", padx=S(16), pady=S(12))
        self.font_preview.pack(anchor="w", fill="x", pady=(0, S(6)))

        lab("Note text size", self.f_body, "fg", (S(8), S(6)))
        group([{"value": k, "label": v[0], "width": S(100)} for k, v in SIZES.items()],
              "size", 4)

        lab("Behaviour", self.f_section, "fg", (S(20), S(10)))
        self.set_top_switch = Switch(body, self, "Always on top", self.on_top, self.set_on_top)
        self.set_top_switch.pack(anchor="w", pady=(0, S(8)))
        self.draw_widgets.append(self.set_top_switch)
        lab("When Quick Notes opens, show", self.f_body, "fg", (S(4), S(6)))
        group([{"value": "home", "label": "The Home page", "width": S(150)},
               {"value": "note", "label": "A blank note", "width": S(150)}],
              "start", 2)

        lab("Your notes", self.f_section, "fg", (S(20), S(10)))
        lab("Saved as plain .txt files on this PC. Nothing is sent anywhere.",
            self.f_small, "muted", (0, S(4)))
        self.folder_path_lbl = lab(str(self.dir), self.f_small, "fg", (0, S(8)))
        self.folder_path_lbl.configure(wraplength=S(520))
        row = tk.Frame(body)
        row.pack(anchor="w")
        self.page_frames.append(row)
        self.set_folder_btn = Pill(row, self, "Open notes folder", self.open_folder)
        self.set_folder_btn.pack(side="left")
        self.reset_btn = Pill(row, self, "Reset settings", self.reset_settings)
        self.reset_btn.pack(side="left", padx=(S(10), 0))
        self.draw_widgets += [self.set_folder_btn, self.reset_btn]

    # ------------------------------------------------------------- theming
    def apply_theme(self) -> None:
        s = self.settings
        c = self.c = resolve_theme(s["theme"], s["accent"])
        self.root.configure(bg=c["bg"])
        for w in (self.side, self.head, self.list_wrap, self.list_inner, self.nav):
            w.configure(bg=c["side"])
        self.nav_line.configure(bg=c["ghost_hover"])
        self.list_canvas.configure(bg=c["side"])
        self.set_canvas.configure(bg=c["bg"])
        self.font_preview.configure(bg=c["side"], fg=c["fg"])
        self.font_entry.configure(bg=c["search"], fg=c["fg"], insertbackground=c["fg"],
                                  highlightbackground=c["ghost_hover"],
                                  highlightcolor=c["accent"])
        for w in self.page_frames:
            w.configure(bg=c["bg"])
        self.title_lbl.configure(bg=c["side"], fg=c["fg"])
        self.count_lbl.configure(bg=c["side"], fg=c["muted"])
        for lbl, key in self.page_labels + self.shortcut_labels:
            lbl.configure(bg=c["bg"], fg=c[key])
        for w in (self.meta_lbl, self.status_lbl, self.ph, self.ph_tip):
            w.configure(bg=c["bg"], fg=c["muted"])
        if self.empty_lbl is not None:
            self.empty_lbl.configure(bg=c["side"], fg=c["muted"])
        self.text.configure(
            bg=c["bg"], fg=c["fg"], insertbackground=c["accent"],
            selectbackground=c["seltext"], selectforeground=c["fg"],
            inactiveselectbackground=c["seltext"],
        )
        self.update_nav()
        self.draw_search()
        for obj in self.draw_widgets:
            obj.draw()
        for card in self.cards + self.home_cards:
            card.draw()
        set_titlebar_dark(self.root, c["dark"])

    def apply_font(self) -> None:
        s = self.settings
        for f in self.ui_fonts:
            f.configure(family=s["font"])
        self.f_editor.configure(family=s["font"], size=SIZES[s["size"]][1])
        self.refit()
        self.update_ph()

    def refit(self) -> None:
        """Re-measure buttons and re-draw custom widgets after a font change."""
        for obj in self.draw_widgets:
            if hasattr(obj, "fit"):
                obj.fit()
        self.root.update_idletasks()
        self.draw_search()
        for obj in self.draw_widgets:
            obj.draw()
        for card in self.cards + self.home_cards:
            card.draw()

    def use_custom_font(self) -> None:
        name = self.font_entry.get().strip()
        if not name:
            return
        match = {f.lower(): f for f in self.all_fonts}.get(name.lower())
        if not match:
            self.font_msg.configure(
                text=f"“{name}” isn’t installed on this PC. Check the spelling.")
            return
        self.groups["font"].set(match)
        self.set_option("font", match)
        self.font_msg.configure(text=f"Now using {match}.")

    def update_nav(self) -> None:
        c = self.c
        for lbl, name in ((self.home_lbl, "home"), (self.settings_lbl, "settings")):
            lbl.configure(bg=c["side"], fg=c["accent"] if self.page == name else c["muted"])

    # ------------------------------------------------------------ settings
    def set_option(self, key: str, value) -> None:
        self.settings[key] = value
        save_settings(self.settings)
        if key in ("theme", "accent"):
            self.apply_theme()
        elif key in ("font", "size"):
            if key == "font":
                self.font_msg.configure(text="")
            self.apply_font()

    def set_on_top(self, on: bool) -> None:
        self.on_top = on
        self.settings["on_top"] = on
        self.root.attributes("-topmost", on)
        for sw in (self.top_switch, self.set_top_switch):
            sw.on = on
            sw.draw()
        save_settings(self.settings)

    def reset_settings(self) -> None:
        self.settings = dict(DEFAULTS)
        self.settings["font"] = self.default_font()
        for key, grp in self.groups.items():
            grp.set(self.settings[key])
        self.font_entry.delete(0, "end")
        self.font_msg.configure(text="")
        self.set_on_top(False)
        self.apply_font()
        self.apply_theme()
        save_settings(self.settings)

    # ------------------------------------------------------------- pages
    def show_page(self, name: str) -> None:
        self.page = name
        for p in (self.editor_page, self.home_page, self.settings_page):
            p.pack_forget()
        page = {"editor": self.editor_page, "home": self.home_page,
                "settings": self.settings_page}[name]
        page.pack(fill="both", expand=True)
        if name == "home":
            self.refresh_home()
        if name == "editor":
            self.text.focus_set()
        else:
            try:
                if self.root.focus_get() is self.text:
                    self.root.focus_set()
            except KeyError:
                pass
        self.update_nav()
        for card in self.cards:
            card.draw()

    def refresh_home(self) -> None:
        hour = time.localtime().tm_hour
        greet = ("Good morning" if hour < 12 else
                 "Good afternoon" if hour < 18 else "Good evening")
        total, entries = self.scan()
        self.greet_lbl.configure(text=greet)
        if total == 0:
            sub = "Welcome! Start your first note — it takes one click."
        else:
            sub = (f"You have {total} note{'s' if total != 1 else ''}. "
                   "Pick one up, or start something new.")
        self.home_sub.configure(text=sub)

        for card in self.home_cards:
            card.destroy()
        self.home_cards = []
        for child in self.recent_frame.winfo_children():
            child.destroy()
        S = self.S
        if not entries:
            lbl = tk.Label(self.recent_frame, text="Your recent notes will show up here.",
                           font=self.f_small, bg=self.c["bg"], fg=self.c["muted"], anchor="w")
            lbl.pack(anchor="w")
        for m, p, text in entries[:3]:
            card = NoteCard(self.recent_frame, self, p, tile=True)
            card.pack(fill="x", pady=S(3))
            card.set_data(title_of(text), preview_of(text), stamp_of(m))
            self.home_cards.append(card)

    def build_shortcuts(self) -> None:
        for w in self.shortcut_rows.winfo_children():
            w.destroy()
        rows = [("Ctrl + N", "Start a new note"),
                ("Ctrl + F", "Search your notes"),
                ("Ctrl + D", "Delete the open note (press twice)")]
        if self.hotkey_ok:
            rows.insert(1, ("Ctrl + Alt + N", "New note from any program"))
        self.shortcut_labels = []
        S, c = self.S, self.c
        for i, (key, desc) in enumerate(rows):
            a = tk.Label(self.shortcut_rows, text=key, font=self.f_card_title, anchor="w",
                         bg=c["bg"], fg=c["fg"])
            a.grid(row=i, column=0, sticky="w", padx=(0, S(24)), pady=S(2))
            b = tk.Label(self.shortcut_rows, text=desc, font=self.f_small, anchor="w",
                         bg=c["bg"], fg=c["muted"])
            b.grid(row=i, column=1, sticky="w", pady=S(2))
            self.shortcut_labels += [(a, "fg"), (b, "muted")]

    # ------------------------------------------------------------- search
    def draw_search(self, _e=None) -> None:
        cv, c, S = self.search_box, self.c, self.S
        cv.configure(bg=c["side"])
        cv.delete("shape")
        w, h = cv.winfo_width(), cv.winfo_height()
        if w < 20:
            return
        round_rect(cv, 1, 1, w - 1, h - 1, S(12), fill=c["search"], outline="", tags="shape")
        cv.tag_lower("shape")
        cv.coords(self.search_win, S(16), h / 2)
        cv.itemconfigure(self.search_win, width=w - S(32), height=h - S(14))
        self.search_entry.configure(
            bg=c["search"], fg=c["muted"] if self.ph_on else c["fg"],
            insertbackground=c["fg"])

    def search_focus_in(self, _e=None) -> None:
        if self.ph_on:
            self.ph_on = False
            self.search_entry.delete(0, "end")
            self.search_entry.configure(fg=self.c["fg"])

    def search_focus_out(self, _e=None) -> None:
        if not self.search_entry.get():
            self.ph_on = True
            self.search_entry.insert(0, PLACEHOLDER)
            self.search_entry.configure(fg=self.c["muted"])

    def get_query(self) -> str:
        return "" if self.ph_on else self.query.get()

    def on_query(self, *_a) -> None:
        if self.ph_on:
            return
        self.refresh_list()

    # ------------------------------------------------------------ actions
    def open_folder(self) -> None:
        try:
            if sys.platform == "win32":
                os.startfile(str(self.dir))  # type: ignore[attr-defined]
            else:
                subprocess.Popen(["xdg-open", str(self.dir)])
        except Exception:
            pass

    def on_wheel(self, e) -> None:
        try:
            w = self.root.winfo_containing(e.x_root, e.y_root)
        except Exception:
            return
        while w is not None:
            if w is self.list_canvas or w is self.set_canvas:
                if w.yview() != (0.0, 1.0):
                    w.yview_scroll(-1 if e.delta > 0 else 1, "units")
                return
            w = w.master

    # ----------------------------------------------------------- hotkey
    def poll_hotkey(self) -> None:
        try:
            while True:
                ev = self.hotkey_q.get_nowait()
                if ev in ("hotkey_ok", "hotkey_fail"):
                    self.hotkey_ok = ev == "hotkey_ok"
                    self.update_tip()
                elif ev == "hotkey":
                    self.summon()
        except queue.Empty:
            pass
        self.root.after(150, self.poll_hotkey)

    def summon(self) -> None:
        self.root.deiconify()
        self.root.lift()
        self.root.attributes("-topmost", True)
        self.root.after(200, lambda: self.root.attributes("-topmost", self.on_top))
        self.root.focus_force()
        self.new_note()

    def update_tip(self) -> None:
        lines = ["Your note saves automatically.",
                 "Press Ctrl+N any time for a new note."]
        if self.hotkey_ok:
            lines.append("Press Ctrl+Alt+N from any program to open a new note.")
        self.ph_tip.configure(text="\n".join(lines))
        self.build_shortcuts()

    # ------------------------------------------------------- note logic
    def read(self, path: Path) -> str:
        try:
            m = path.stat().st_mtime
            hit = self.cache.get(path)
            if hit and hit[0] == m:
                return hit[1]
            text = path.read_text(encoding="utf-8")
            self.cache[path] = (m, text)
            return text
        except (OSError, UnicodeDecodeError):
            return ""

    def scan(self, q: str = ""):
        entries = []
        total = 0
        for p in self.dir.glob("*.txt"):
            try:
                m = p.stat().st_mtime
            except OSError:
                continue
            total += 1
            text = self.read(p)
            if q and q not in text.lower():
                continue
            entries.append((m, p, text))
        entries.sort(key=lambda t: t[0], reverse=True)
        return total, entries

    def refresh_list(self) -> None:
        q = self.get_query().strip().lower()
        total, entries = self.scan(q)
        self.paths = [p for _, p, _ in entries]
        data = [(p, title_of(t), preview_of(t), stamp_of(m)) for m, p, t in entries]

        if self.cards and [d[0] for d in data] == [cd.path for cd in self.cards]:
            for card, d in zip(self.cards, data):
                card.set_data(d[1], d[2], d[3])
        else:
            self.rebuild_cards(data, bool(q))
        self.count_lbl.configure(text=f"{total} note{'s' if total != 1 else ''}")

    def rebuild_cards(self, data, searching: bool) -> None:
        for card in self.cards:
            card.destroy()
        self.cards = []
        if self.empty_lbl is not None:
            self.empty_lbl.destroy()
            self.empty_lbl = None
        S = self.S
        if not data:
            msg = ("No notes match your search." if searching else
                   "No notes yet.\nClick “New note”, or just\nstart typing on the right.")
            self.empty_lbl = tk.Label(self.list_inner, text=msg, font=self.f_small,
                                      bg=self.c["side"], fg=self.c["muted"], justify="left")
            self.empty_lbl.pack(anchor="w", padx=S(12), pady=S(20))
        for path, title, preview, stamp in data:
            card = NoteCard(self.list_inner, self, path)
            card.pack(fill="x", padx=S(4), pady=S(2))
            card.set_data(title, preview, stamp)
            self.cards.append(card)
        self.list_canvas.yview_moveto(0)

    def select_path(self, path: Path) -> None:
        if path != self.current:
            self.flush()
            self.discard_if_empty()
            self.open_note(path)
        self.show_page("editor")

    def open_note(self, path: "Path | None") -> None:
        self.disarm()
        self.loading = True
        self.current = path
        self.text.delete("1.0", "end")
        if path is not None:
            self.text.insert("1.0", self.read(path))
        self.text.edit_reset()
        self.text.edit_modified(False)
        self.loading = False
        self.update_ph()
        self.update_meta()
        self.update_status()

    def new_note(self) -> None:
        self.flush()
        self.discard_if_empty()
        self.open_note(None)
        self.show_page("editor")

    def discard_if_empty(self) -> None:
        if self.current is not None and not self.read(self.current).strip():
            try:
                self.current.unlink()
            except OSError:
                pass
            self.cache.pop(self.current, None)
            self.current = None
            self.refresh_list()

    def on_modified(self, _event=None) -> None:
        if not self.text.edit_modified():
            return
        self.text.edit_modified(False)
        self.update_ph()
        if self.loading:
            return
        if self.save_job:
            self.root.after_cancel(self.save_job)
        self.save_job = self.root.after(500, self.save)
        self.update_status(dirty=True)

    def flush(self) -> None:
        if self.save_job:
            self.root.after_cancel(self.save_job)
            self.save_job = None
            self.save()

    def save(self) -> None:
        self.save_job = None
        text = self.text.get("1.0", "end-1c")
        if self.current is None:
            if not text.strip():
                return
            base = time.strftime("%Y%m%d-%H%M%S")
            path = self.dir / f"{base}.txt"
            n = 1
            while path.exists():
                path = self.dir / f"{base}-{n}.txt"
                n += 1
            self.current = path
        try:
            self.current.write_text(text, encoding="utf-8")
        except OSError as exc:
            self.status_lbl.configure(text=f"Could not save: {exc}")
            return
        self.refresh_list()
        self.update_meta()
        self.update_status()

    # ---------------------------------------------------- delete (2 clicks)
    def delete_clicked(self) -> None:
        if self.page != "editor":
            return
        if self.current is None:
            self.text.delete("1.0", "end")
            return
        if not self.del_btn.armed:
            self.del_btn.armed = True
            self.del_btn.set_label(DELETE_CONFIRM)
            self.armed_job = self.root.after(3000, self.disarm)
            return
        self.disarm()
        self.delete_note()

    def disarm(self) -> None:
        if self.armed_job:
            self.root.after_cancel(self.armed_job)
            self.armed_job = None
        if self.del_btn.armed:
            self.del_btn.armed = False
            self.del_btn.set_label(DELETE_LABEL)

    def delete_note(self) -> None:
        if self.current is None:
            return
        if self.save_job:
            self.root.after_cancel(self.save_job)
            self.save_job = None
        try:
            self.current.unlink()
        except OSError:
            pass
        self.cache.pop(self.current, None)
        self.current = None
        self.open_note(None)
        self.refresh_list()
        self.show_page("home")

    # ------------------------------------------------------ small updates
    def update_ph(self) -> None:
        if self.text.get("1.0", "end-1c"):
            self.ph.place_forget()
            self.ph_tip.place_forget()
        else:
            S = self.S
            self.ph.place(x=S(32), y=S(14))
            gap = self.f_editor.metrics("linespace") + S(12)
            self.ph_tip.place(x=S(32), y=S(14) + gap)

    def update_meta(self) -> None:
        label = "New note"
        if self.current is not None:
            try:
                label = edited_text(self.current.stat().st_mtime)
            except OSError:
                pass
        self.meta_lbl.configure(text=label)

    def update_status(self, dirty: bool = False) -> None:
        text = self.text.get("1.0", "end-1c")
        words = len(text.split())
        parts = []
        if self.current is not None or text.strip():
            parts.append(f"{words} word{'s' if words != 1 else ''}")
        if dirty:
            parts.append("Saving…")
        elif self.current is not None:
            parts.append("All changes saved")
        self.status_lbl.configure(text="    ·    ".join(parts))

    def on_close(self) -> None:
        self.flush()
        self.discard_if_empty()
        self.root.destroy()


def main() -> None:
    enable_dpi_awareness()
    root = tk.Tk()
    QuickNotes(root)
    root.mainloop()


if __name__ == "__main__":
    main()
